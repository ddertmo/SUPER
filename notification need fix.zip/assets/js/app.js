// ============================================================
// CIVILWATCH Admin Dashboard — App Shell
// Handles: Sidebar, Navbar, Notifications Panel
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

const App = {

  sidebarCollapsed: false,

  init() {
    this.renderSidebar();
    this.renderNavbar();
    this.renderNotifPanel();
    this.bindEvents();
    this.setActiveNav();
    this.loadTheme();
  },

  // ── Role helpers ──────────────────────────────────────────
  getRole()  { return localStorage.getItem('cw_role')  || 'superadmin'; },
  getName()  { return localStorage.getItem('cw_name')  || 'Super Administrator'; },
  getTitle() { return localStorage.getItem('cw_title') || 'Super Admin'; },
  getInitials() {
    return this.getName().split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  },

  // ── Sidebar HTML ──────────────────────────────────────────
  renderSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;

    const role = this.getRole();

    // ── Determine base path prefix (office pages are 2 levels deep) ──
    const depth = window.location.pathname.includes('/offices/') ? '../../' : '';

    // ── Logo / branding ───────────────────────────────────
    let logoBrand = '';
    if (role === 'ceo') {
      logoBrand = `
        <div class="sidebar-logo">
          <div class="sidebar-logo-icon" style="background:rgba(255,255,255,0.15);">
            <span class="material-symbols-outlined">business</span>
          </div>
          <div class="sidebar-logo-text">
            <div class="sidebar-logo-title" style="font-size:11px;line-height:1.3;">CITY ENGINEERING<br>OFFICE</div>
          </div>
        </div>`;
    } else if (role === 'cenro') {
      logoBrand = `
        <div class="sidebar-logo">
          <div class="sidebar-logo-icon" style="background:rgba(255,255,255,0.15);">
            <span class="material-symbols-outlined">eco</span>
          </div>
          <div class="sidebar-logo-text">
            <div class="sidebar-logo-title" style="font-size:11px;line-height:1.3;">CENRO<br></div>
            <div class="sidebar-logo-subtitle">Environmental Office</div>
          </div>
        </div>`;
    } else {
      logoBrand = `
        <div class="sidebar-logo">
          <div class="sidebar-logo-icon">
            <span class="material-symbols-outlined">shield</span>
          </div>
          <div class="sidebar-logo-text">
            <div class="sidebar-logo-title">CIVILWATCH</div>
            <div class="sidebar-logo-subtitle">Digos City</div>
          </div>
        </div>`;
    }

    // ── Nav items per role ─────────────────────────────────
    let navItems = '';
    if (role === 'superadmin') {
      navItems = `
        <a class="nav-item" href="${depth}dashboard.html" data-page="dashboard">
          <span class="material-symbols-outlined">dashboard</span>
          <span class="nav-item-label">Dashboard</span>
        </a>
        <a class="nav-item" href="${depth}pending-reports.html" data-page="pending-reports">
          <span class="material-symbols-outlined">pending_actions</span>
          <span class="nav-item-label">Pending Reports</span>
          <span class="nav-badge">24</span>
        </a>
        <a class="nav-item" href="${depth}assign-office.html" data-page="assign-office">
          <span class="material-symbols-outlined">assignment_ind</span>
          <span class="nav-item-label">Assign Office</span>
        </a>
        <a class="nav-item" href="${depth}monitoring.html" data-page="monitoring">
          <span class="material-symbols-outlined">track_changes</span>
          <span class="nav-item-label">Monitoring</span>
        </a>
        <a class="nav-item" href="${depth}gis-map.html" data-page="gis-map">
          <span class="material-symbols-outlined">map</span>
          <span class="nav-item-label">GIS Map</span>
        </a>
        <a class="nav-item" href="${depth}analytics.html" data-page="analytics">
          <span class="material-symbols-outlined">bar_chart</span>
          <span class="nav-item-label">Analytics</span>
        </a>
        <a class="nav-item" href="${depth}resolved-reports.html" data-page="resolved-reports">
          <span class="material-symbols-outlined">task_alt</span>
          <span class="nav-item-label">Resolved Reports</span>
        </a>
        <a class="nav-item" href="${depth}users.html" data-page="users">
          <span class="material-symbols-outlined">group</span>
          <span class="nav-item-label">Users</span>
        </a>
        <a class="nav-item" href="${depth}settings.html" data-page="settings">
          <span class="material-symbols-outlined">settings</span>
          <span class="nav-item-label">Settings</span>
        </a>`;
    } else if (role === 'ceo') {
      navItems = `
        <a class="nav-item" href="${depth}offices/ceo/dashboard.html" data-page="dashboard">
          <span class="material-symbols-outlined">dashboard</span>
          <span class="nav-item-label">Dashboard</span>
        </a>
        <a class="nav-item" href="${depth}offices/ceo/reports.html" data-page="reports">
          <span class="material-symbols-outlined">assignment</span>
          <span class="nav-item-label">My Assigned Reports</span>
        </a>
        <a class="nav-item" href="${depth}offices/ceo/inprogress.html" data-page="inprogress">
          <span class="material-symbols-outlined">autorenew</span>
          <span class="nav-item-label">Active Reports</span>
        </a>
        <a class="nav-item" href="${depth}offices/ceo/resolved.html" data-page="resolved">
          <span class="material-symbols-outlined">task_alt</span>
          <span class="nav-item-label">Resolved Reports</span>
        </a>
        <a class="nav-item" href="${depth}offices/ceo/map.html" data-page="map">
          <span class="material-symbols-outlined">map</span>
          <span class="nav-item-label">Map</span>
        </a>
        <a class="nav-item" href="${depth}offices/ceo/analytics.html" data-page="analytics">
          <span class="material-symbols-outlined">bar_chart</span>
          <span class="nav-item-label">Analytics</span>
        </a>
        <a class="nav-item" href="${depth}offices/ceo/settings.html" data-page="settings">
          <span class="material-symbols-outlined">settings</span>
          <span class="nav-item-label">Settings</span>
        </a>`;
    } else if (role === 'cenro') {
      navItems = `
        <a class="nav-item" href="${depth}offices/cenro/dashboard.html" data-page="dashboard">
          <span class="material-symbols-outlined">dashboard</span>
          <span class="nav-item-label">Dashboard</span>
        </a>
        <a class="nav-item" href="${depth}offices/cenro/reports.html" data-page="reports">
          <span class="material-symbols-outlined">assignment</span>
          <span class="nav-item-label">My Assigned Reports</span>
        </a>
        <a class="nav-item" href="${depth}offices/cenro/inprogress.html" data-page="inprogress">
          <span class="material-symbols-outlined">autorenew</span>
          <span class="nav-item-label">Active Reports</span>
        </a>
        <a class="nav-item" href="${depth}offices/cenro/resolved.html" data-page="resolved">
          <span class="material-symbols-outlined">task_alt</span>
          <span class="nav-item-label">Resolved Reports</span>
        </a>
        <a class="nav-item" href="${depth}offices/cenro/map.html" data-page="map">
          <span class="material-symbols-outlined">map</span>
          <span class="nav-item-label">Map</span>
        </a>
        <a class="nav-item" href="${depth}offices/cenro/analytics.html" data-page="analytics">
          <span class="material-symbols-outlined">bar_chart</span>
          <span class="nav-item-label">Analytics</span>
        </a>
        <a class="nav-item" href="${depth}offices/cenro/settings.html" data-page="settings">
          <span class="material-symbols-outlined">settings</span>
          <span class="nav-item-label">Settings</span>
        </a>`;
    }

    // ── Logout link ────────────────────────────────────────
    const logoutLink = `
      <a class="nav-item" href="#" onclick="App.logout(event)" style="margin-top:4px;">
        <span class="material-symbols-outlined">logout</span>
        <span class="nav-item-label">Logout</span>
      </a>`;

    sidebar.innerHTML = `
      ${logoBrand}
      <nav class="sidebar-nav">
        ${navItems}
        ${logoutLink}
      </nav>
      <div class="sidebar-footer">
        <div class="sidebar-user">
          <div class="sidebar-user-avatar">${this.getInitials()}</div>
          <div class="sidebar-user-info">
            <div class="sidebar-user-name">${this.getName()}</div>
            <div class="sidebar-user-role">${this.getTitle()}</div>
          </div>
        </div>
        <div class="sidebar-user-status" style="padding: 2px 12px 8px; margin-left: 2px;">
          <div class="status-dot"></div>
          <span style="font-size:11px; color:rgba(255,255,255,0.5)">Online</span>
        </div>
      </div>
    `;

    // ── Apply green theme for CENRO ────────────────────────
    if (role === 'cenro') {
      sidebar.style.setProperty('--sidebar-bg', '#166534');
      sidebar.style.background = 'linear-gradient(180deg, #166534 0%, #14532d 100%)';
    }
  },

  // ── Navbar HTML ───────────────────────────────────────────
  renderNavbar() {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;
    navbar.innerHTML = `
      <div class="navbar-left">
        <button class="navbar-toggle" id="sidebarToggle" title="Toggle sidebar">
          <span class="material-symbols-outlined">menu</span>
        </button>
        <div class="navbar-search">
          <span class="material-symbols-outlined navbar-search-icon">search</span>
          <input type="text" placeholder="Search reports, locations..." id="globalSearch" />
        </div>
      </div>
      <div class="navbar-right">
        <button class="navbar-icon-btn" id="darkModeBtn" title="Toggle Dark Mode">
          <span class="material-symbols-outlined" id="darkModeIcon">dark_mode</span>
        </button>
        <button class="navbar-icon-btn" id="notifBtn" title="Notifications">
          <span class="material-symbols-outlined">notifications</span>
          <span class="notif-badge">3</span>
        </button>
        <div class="navbar-profile" id="profileBtn">
          <div class="navbar-avatar">${this.getInitials()}</div>
          <div class="navbar-profile-info">
            <span class="navbar-profile-name">${this.getName()}</span>
            <span class="navbar-profile-role">${this.getTitle()}</span>
          </div>
          <span class="material-symbols-outlined">expand_more</span>
        </div>
      </div>
    `;
  },

  // ── Notifications Panel HTML ──────────────────────────────
  renderNotifPanel() {
    const existing = document.getElementById('notifPanel');
    if (existing) return;

    const panel = document.createElement('div');
    panel.className = 'notif-panel';
    panel.id = 'notifPanel';
    panel.innerHTML = `
      <div class="notif-panel-header">
        <div class="notif-panel-title-wrap">
          <span class="notif-panel-title">Notifications</span>
          <span class="notif-count-badge" id="notifCountBadge">3</span>
        </div>
        <div class="notif-panel-actions">
          <button class="notif-mark-read" id="markAllRead">Mark all as read</button>
          <button class="notif-close" id="notifClose">
            <span class="material-symbols-outlined">close</span>
          </button>
        </div>
      </div>
      <div class="notif-list" id="notifList">
        ${this.buildNotifItems()}
      </div>
      <div class="notif-panel-footer">
        <span class="notif-view-all">
          <span class="material-symbols-outlined">notifications</span>
          View all notifications
          <span class="material-symbols-outlined">arrow_forward</span>
        </span>
      </div>
    `;
    document.body.appendChild(panel);

    // Overlay
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.id = 'notifOverlay';
    overlay.addEventListener('click', () => this.closeNotif());
    document.body.appendChild(overlay);
  },

  buildNotifItems() {
    const items = [
      { type: 'submit',   title: 'New report submitted',  desc: 'A new report "Damaged Road" was submitted in Aplaya.', time: '2 minutes ago', unread: true },
      { type: 'assign',   title: 'Report assigned',        desc: 'Report CW-2026-217 has been assigned to CENRO.',       time: '15 minutes ago', unread: true },
      { type: 'progress', title: 'Status updated',         desc: 'Report CW-2026-213 is now In Progress.',               time: '35 minutes ago', unread: true },
      { type: 'resolved', title: 'Report resolved',        desc: 'Report CW-2026-215 has been marked as Resolved.',      time: '1 hour ago',     unread: false },
      { type: 'comment',  title: 'New comment',            desc: 'A comment was added on report CW-2026-216.',           time: '2 hours ago',    unread: false },
      { type: 'system',   title: 'System notification',    desc: 'Scheduled maintenance on May 25, 2026 at 12:00 AM.',   time: '1 day ago',      unread: false },
    ];
    const iconMap = {
      submit:   { icon: 'description',   cls: 'submit' },
      assign:   { icon: 'person_add',    cls: 'assign' },
      progress: { icon: 'autorenew',     cls: 'progress' },
      resolved: { icon: 'check_circle',  cls: 'resolved' },
      comment:  { icon: 'chat_bubble',   cls: 'comment' },
      system:   { icon: 'notifications', cls: 'system' },
    };
    return items.map(item => {
      const im = iconMap[item.type];
      return `
        <div class="notif-item ${item.unread ? 'unread' : ''}">
          <div class="notif-icon ${im.cls}">
            <span class="material-symbols-outlined">${im.icon}</span>
          </div>
          <div class="notif-content">
            <div class="notif-title">${item.title}</div>
            <div class="notif-desc">${item.desc}</div>
            <div class="notif-time">${item.time}</div>
          </div>
          ${item.unread ? '<div class="unread-dot"></div>' : ''}
        </div>
      `;
    }).join('');
  },

  // ── Event Bindings ────────────────────────────────────────
  bindEvents() {
    // Sidebar toggle
    document.addEventListener('click', e => {
      const toggle = e.target.closest('#sidebarToggle');
      if (toggle) this.toggleSidebar();

      const notifBtn = e.target.closest('#notifBtn');
      if (notifBtn) this.openNotif();

      const notifClose = e.target.closest('#notifClose');
      if (notifClose) this.closeNotif();

      const markAll = e.target.closest('#markAllRead');
      if (markAll) this.markAllRead();

      const darkModeBtn = e.target.closest('#darkModeBtn');
      if (darkModeBtn) this.toggleDarkMode();
    });
  },

  // ── Sidebar toggle ────────────────────────────────────────
  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainArea = document.getElementById('mainArea');
    const navbar = document.getElementById('navbar');
    this.sidebarCollapsed = !this.sidebarCollapsed;
    sidebar?.classList.toggle('collapsed', this.sidebarCollapsed);
    mainArea?.classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
    navbar?.classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
  },

  // ── Notification panel ────────────────────────────────────
  openNotif() {
    document.getElementById('notifPanel')?.classList.add('open');
    document.getElementById('notifOverlay')?.classList.add('active');
  },

  closeNotif() {
    document.getElementById('notifPanel')?.classList.remove('open');
    document.getElementById('notifOverlay')?.classList.remove('active');
  },

  markAllRead() {
    document.querySelectorAll('.notif-item.unread').forEach(el => {
      el.classList.remove('unread');
      el.querySelector('.unread-dot')?.remove();
    });
    const badge = document.querySelector('.notif-badge');
    if (badge) badge.textContent = '0';
    const countBadge = document.getElementById('notifCountBadge');
    if (countBadge) countBadge.textContent = '0';
    Utils.showToast('All notifications marked as read', 'success');
  },

  // ── Dark Mode toggle ──────────────────────────────────────
  toggleDarkMode() {
    const html = document.documentElement;
    const isDark = html.getAttribute('data-theme') === 'dark';
    const newTheme = isDark ? 'light' : 'dark';
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    const icon = document.getElementById('darkModeIcon');
    if (icon) icon.textContent = isDark ? 'dark_mode' : 'light_mode';
    
    Utils.showToast(`${isDark ? 'Light' : 'Dark'} mode enabled`, 'info');
  },

  // ── Load saved theme ──────────────────────────────────────
  loadTheme() {
    const saved = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    const icon = document.getElementById('darkModeIcon');
    if (icon) icon.textContent = saved === 'dark' ? 'light_mode' : 'dark_mode';
  },

  // ── Active nav ────────────────────────────────────────────
  setActiveNav() {
    const page = document.body.dataset.page;
    if (!page) return;
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.page === page);
    });
  },

  // ── Logout ────────────────────────────────────────────────
  logout(e) {
    if (e) e.preventDefault();
    localStorage.removeItem('cw_role');
    localStorage.removeItem('cw_name');
    localStorage.removeItem('cw_title');
    // Navigate back to login — handle depth for office pages
    const depth = window.location.pathname.includes('/offices/') ? '../../' : '';
    window.location.href = depth + 'index.html';
  }
};
